import java.util.Arrays;
import java.util.Scanner;

class B3A1 {
    public static int removeDuplicates(int[] data) {
        /**********************************************************/
        /**** Kurzaufgabe 3.1: ****/

        // Ersetzen Sie diese Kommentarzeile durch Ihren Code!

        /**********************************************************/
        return 0;
    }

    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        Scanner input = new Scanner(System.in);
        // Initialize the scanner and read the amount of expected integers
        int n = input.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }
        input.close();
        System.out.print("Before removing duplicates: ");
        System.out.println(Arrays.toString(arr));
        int distinct = removeDuplicates(arr);
        /**********************************************************/
        /**** Kurzaufgabe 3.1: ****/

        // Ersetzen Sie diese Kommentarzeile durch Ihren Code!

        /**********************************************************/

    }

}
